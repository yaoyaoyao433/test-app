;(function () {
  var loadJS = function () {
    if (window.document && document.body) {
      window.__pageLoadMainPkgStartTime = Date.now()
      var script = document.createElement('script')
      script.setAttribute('type', 'text/javascript')
      script.setAttribute('src', '/__app/main_app/app-page.js')
      document.body.appendChild(script)
    } else {
      setTimeout(loadJS, 10)
    }
  }
  loadJS()
})();