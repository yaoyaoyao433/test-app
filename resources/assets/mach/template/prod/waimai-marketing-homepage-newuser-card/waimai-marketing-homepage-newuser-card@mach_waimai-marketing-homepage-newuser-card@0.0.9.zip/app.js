this.global = this.window = this.self = this.self || this;this.default=
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _Bridge = _interopRequireDefault(__webpack_require__(1));

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

var _default = {
  env: {},
  value: {
    is_upper_section_valid: false,
    is_lower_section_valid: false,
    section_a_item: {},
    section_b_item: {},
    section_c_item: {},
    computed: {}
  },
  api: {},
  initProps: function initProps() {
    // api数据非法 隐藏所有瓷片
    if (!this.api.hasOwnProperty("areaItemList")) {
      this.value.is_upper_section_valid = false;
      this.value.is_lower_section_valid = false;
      return;
    }

    var areaItemList = this.api["areaItemList"]; //api数据非法 隐藏所有瓷片

    if (areaItemList.length == 0) {
      this.value.is_upper_section_valid = false;
      this.value.is_lower_section_valid = false;
      return;
    } // 展示所有瓷片


    if (areaItemList.length >= 3) {
      this.value.is_upper_section_valid = true;
      this.value.is_lower_section_valid = true;
      this.value.section_a_item = areaItemList[0];
      this.value.section_b_item = areaItemList[1];
      this.value.section_c_item = areaItemList[2];
    } // 展示下层瓷片


    if (areaItemList.length == 2) {
      this.value.is_upper_section_valid = false;
      this.value.is_lower_section_valid = true;
      this.value.section_b_item = areaItemList[0];
      this.value.section_c_item = areaItemList[1];
    } // 展示上层瓷片


    if (areaItemList.length == 1) {
      this.value.is_upper_section_valid = true;
      this.value.is_lower_section_valid = false;
      this.value.section_a_item = areaItemList[0];
    } // 添加埋点所需额外数据


    this.value.section_a_item["entryIndex"] = 1;
    this.value.section_a_item["layoutType"] = areaItemList.length;
    this.value.section_b_item["entryIndex"] = 2;
    this.value.section_b_item["layoutType"] = areaItemList.length;
    this.value.section_c_item["entryIndex"] = 3;
    this.value.section_c_item["layoutType"] = areaItemList.length;
  },
  viewLXReportSectionA: function viewLXReportSectionA() {
    return {
      "bid": "b_y0odae12",
      "lab": {
        "entry_id": this.value.section_a_item.entryId,
        "entry_item_id": this.value.section_a_item.entryItemId,
        "activity_id": this.value.section_a_item.activityId,
        "entry_index": this.value.section_a_item.entryIndex,
        "layout_type": this.value.section_a_item.layoutType
      }
    };
  },
  clickLXReportSectionA: function clickLXReportSectionA() {
    return {
      "bid": "b_zopkupx4",
      "lab": {
        "entry_id": this.value.section_a_item.entryId,
        "entry_item_id": this.value.section_a_item.entryItemId,
        "activity_id": this.value.section_a_item.activityId,
        "entry_index": this.value.section_a_item.entryIndex,
        "layout_type": this.value.section_a_item.layoutType
      }
    };
  },
  viewLXReportSectionB: function viewLXReportSectionB() {
    return {
      "bid": "b_y0odae12",
      "lab": {
        "entry_id": this.value.section_b_item.entryId,
        "entry_item_id": this.value.section_b_item.entryItemId,
        "activity_id": this.value.section_b_item.activityId,
        "entry_index": this.value.section_b_item.entryIndex,
        "layout_type": this.value.section_b_item.layoutType
      }
    };
  },
  clickLXReportSectionB: function clickLXReportSectionB() {
    return {
      "bid": "b_zopkupx4",
      "lab": {
        "entry_id": this.value.section_b_item.entryId,
        "entry_item_id": this.value.section_b_item.entryItemId,
        "activity_id": this.value.section_b_item.activityId,
        "entry_index": this.value.section_b_item.entryIndex,
        "layout_type": this.value.section_b_item.layoutType
      }
    };
  },
  viewLXReportSectionC: function viewLXReportSectionC() {
    return {
      "bid": "b_y0odae12",
      "lab": {
        "entry_id": this.value.section_c_item.entryId,
        "entry_item_id": this.value.section_c_item.entryItemId,
        "activity_id": this.value.section_c_item.activityId,
        "entry_index": this.value.section_c_item.entryIndex,
        "layout_type": this.value.section_c_item.layoutType
      }
    };
  },
  clickLXReportSectionC: function clickLXReportSectionC() {
    return {
      "bid": "b_zopkupx4",
      "lab": {
        "entry_id": this.value.section_c_item.entryId,
        "entry_item_id": this.value.section_c_item.entryItemId,
        "activity_id": this.value.section_c_item.activityId,
        "entry_index": this.value.section_c_item.entryIndex,
        "layout_type": this.value.section_c_item.layoutType
      }
    };
  },
  setApiValue: function setApiValue(api) {
    this.api = api;
  },
  setMachEnv: function setMachEnv(env) {
    this.env = env;
  }
};
exports["default"] = _default;
Object.defineProperty(_default, "computed", {
  get: function () {
    return _default.value.computed;
  }
});

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var MachBridge = /** @class */ (function () {
    function MachBridge() {
        this.context = {
            callbacks: {},
            nativeModuleCallback: {},
            handleNativeCallback: {}
        };
        this.machCallbackId = 0;
        this.callbacks = {};
    }
    MachBridge.prototype.machRegister = function (context) {
        if (this.context !== context) {
            this.context = context;
            this.context["callbacks"] = {};
            this.context["nativeModuleCallback"] = this.nativeModuleCallback;
            this.context["handleNativeCallback"] = this.handleNativeCallback;
        }
    };
    MachBridge.prototype.machUnregister = function () {
        delete this.context["nativeModuleCallback"];
        delete this.context["handleNativeCallback"];
        delete this.context["callbacks"];
    };
    MachBridge.prototype.generatorCallbackId = function () {
        return "__mach_cb_id__" + this.machCallbackId++;
    };
    MachBridge.prototype.getMachNativeModule = function (module, method, args, callback) {
        var callbackId = this.generatorCallbackId();
        this.context["callbacks"][callbackId] = callback;
        MachNative.invokeNativeBridge(module, method, args, callbackId);
    };
    MachBridge.prototype.nativeModuleCallback = function (callbackId, result) {
        var object = {
            status: 0,
            data: ''
        };
        var ret = {
            code: 0,
            data: ''
        };
        try {
            object = JSON.parse(result);
        }
        catch (e) {
            console.log("illegal result from native." + e);
            object.status = -1;
            object.data = "illegal result from native.";
        }
        finally {
            ret.code = object.status;
            ret.data = object.data;
        }
        this.handleNativeCallback(callbackId, ret);
    };
    MachBridge.prototype.handleNativeCallback = function (callbackId, result) {
        if (this.callbacks[callbackId]) {
            if (result.code === 0) {
                this.callbacks[callbackId].call(this, result, undefined);
            }
            else {
                this.callbacks[callbackId].call(this, undefined, result);
            }
            delete this.callbacks[callbackId];
        }
        else {
            console.log('can not find callback for the call.');
        }
    };
    return MachBridge;
}());
var instance = new MachBridge();
exports.default = instance;


/***/ })
/******/ ]);
if (this.customConfig && this.customConfig.name) {this[this.customConfig.name] = this.default.default} else {this.defaultObject = this.default.default};this.default=null;