this.global = this.window = this.self = this.self || this;this.default=
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0; // import KNB from "./bridge/KNBBridge"
// import MachBridge from "./bridge/Bridge"

var _default = {
  env: {},
  value: {
    viewLXReport: {
      bid: 'b_waimai_bkcugylo_mv',
      lab: {
        ":message_id": "api.msg_id",
        ":task_id": "api.task_id",
        "template_id": "waimai-mach-marketing-push-style-1",
        ":biz_type": "api.biz_type",
        ":biz_resource_id": "api.biz_resource_id",
        ":button_name": "api.btn.text"
      }
    }
  },
  api: {},
  created: function created() {},
  initProps: function initProps() {
    this.api.task_id = this.api.biz_task_id ? this.api.biz_task_id : 0;
    var formatText = this.formatRichText(this.api.text, "#333333", "16dp");
    this.api.text = formatText;
    var formatTitle = this.formatRichText(this.api.title, "#666666", "14dp");
    this.api.title = formatTitle;
  },
  clickLXReport: function clickLXReport() {
    return {
      bid: "b_waimai_bkcugylo_mc",
      lab: {
        "message_id": this.api.msg_id,
        "task_id": this.api.task_id,
        "template_id": "waimai-mach-marketing-push-style-1",
        "biz_type": this.api.biz_type,
        "biz_resource_id": this.api.biz_resource_id,
        "button_name": this.api.btn !== undefined && this.api.btn.text !== undefined && this.api.btn.text.length > 0 ? this.api.btn.text : ""
      }
    };
  },
  jumpPage: function jumpPage() {
    var param = {};

    if (this.api.btn !== undefined && this.api.btn.text !== undefined && this.api.btn.text.length > 0) {
      param = {
        "url": this.api.btn.schema.url
      };
    } else {
      param = {
        "url": this.api.url
      };
    }

    MachNative.sendEvent("jump_with_close", JSON.stringify(param));
  },
  formatRichText: function formatRichText(str, color, size) {
    var starFlag = "<highlight>";
    var endFlag = "</highlight>";
    var result = "";

    while (str.length > 0) {
      var preIndex = str.indexOf(starFlag);

      if (preIndex >= 0 && preIndex <= str.length - 1) {
        var preStr = str.substring(0, preIndex);
        result = result + this.getNormalFormatText(preStr, color, size);
        var surIndex = str.indexOf(endFlag);

        if (surIndex > preIndex && surIndex <= str.length - 1) {
          var midStr = str.substring(preIndex + starFlag.length, surIndex);
          result = result + this.getRichFormatText(midStr, size);
          str = str.substring(surIndex + endFlag.length);
        } else {
          result = result + this.getNormalFormatText(str.substring(preIndex), color, size);
          break;
        }
      } else {
        result = result + this.getNormalFormatText(str, color, size);
        break;
      }
    }

    return result;
  },
  getNormalFormatText: function getNormalFormatText(text, color, size) {
    return "<span style='color:" + color + ";font-size:" + size + ";font-family:PingFangSC-Regular;'>" + text + "</span>";
  },
  getRichFormatText: function getRichFormatText(text, size) {
    return "<span style='color:#FF4A26;font-size:" + size + ";font-family:PingFangSC-Regular;'>" + text + "</span>";
  },
  setApiValue: function setApiValue(api) {
    this.api = api;
  },
  setMachEnv: function setMachEnv(env) {
    this.env = env;
  }
};
exports["default"] = _default;
Object.defineProperty(_default, "viewLXReport", {
  get: function () {
    return _default.value.viewLXReport;
  }
});

/***/ })
/******/ ]);
if (this.customConfig && this.customConfig.name) {this[this.customConfig.name] = this.default.default} else {this.defaultObject = this.default.default};this.default=null;