this.global = this.window = this.self = this.self || this;this.default=
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
// import KNB from "./bridge/KNBBridge"
// import MachBridge from "./bridge/Bridge"
var _default = {
  env: {},
  value: {
    show_view_bid: '',
    computed: {}
  },
  api: {},
  initProps: function initProps() {
    if (this.api.request_page_source == 1) {
      this.value.show_view_bid = "b_4w4e0d3p";
    } else if (this.api.request_page_source == 2) {
      this.value.show_view_bid = "b_kxk0w1it";
    }
    this.api.desc = this.convertToRichtext(this.api.desc);
  },
  getNormalFormatText: function getNormalFormatText(text) {
    return "<span>" + text + "</span>";
  },
  getRichFormatText: function getRichFormatText(text) {
    return "<span style='color:#FF4A26'>" + text + "</span>";
  },
  convertToRichtext: function convertToRichtext(target) {
    // 富文本标记，处理文案高亮使用"
    var starFlag = "<highlight>";
    var endFlag = "</highlight>";
    //待处理文案
    var title = target;
    //初始化处理结果
    var result = "";
    //遍历文案
    while (title.length > 0) {
      var pre_index = title.indexOf(starFlag);
      if (pre_index >= 0 && pre_index <= title.length - 1) {
        var preStr = title.substring(0, pre_index);
        result = result + this.getNormalFormatText(preStr);
        var sur_index = title.indexOf(endFlag);
        if (sur_index > pre_index && sur_index <= title.length - 1) {
          var midStr = title.substring(pre_index + starFlag.length, sur_index);
          result = result + this.getRichFormatText(midStr);
          title = title.substring(sur_index + endFlag.length);
        } else {
          result = result + this.getNormalFormatText(title.substring(pre_index));
          break;
        }
      } else {
        result = result + this.getNormalFormatText(title);
        break;
      }
    }
    //返回处理结果
    return result;
  },
  close: function close() {
    MachNative.sendEvent("close");
  },
  viewLXReport: function viewLXReport() {
    var coupon_source = this.api.couponType == 7 ? 7 : this.api.exchange_type;
    return {
      bid: this.value.show_view_bid,
      lab: {
        "poi_id": this.api.poi_id_str ? this.api.poi_id_str : this.api.poi_id,
        "coupon_source": coupon_source,
        "src_page_id": this.api.request_page_source,
        'red_threshold': this.api.origin_coupon_use_limit,
        'coupon_amount': this.api.poi_coupon_amount,
        'red_label': this.api.coupon_label
      }
    };
  },
  clickUpgradeCoupon: function clickUpgradeCoupon() {
    var params = {};
    params.exchange_type = this.api.exchange_type;
    params.coupon_view_id = this.api.coupon_view_id;
    params.trans_token = this.api.trans_token;
    params.coin_count = this.api.coin_count;
    MachNative.sendEvent("exchange", JSON.stringify(params));
  },
  clickConfiromLXReport: function clickConfiromLXReport() {
    var bid = "";
    if (this.api.request_page_source == 1) {
      bid = "b_8jzqjvgu";
    } else if (this.api.request_page_source == 2) {
      bid = "b_g3a5jcr0";
    }
    var coupon_source = this.api.couponType == 7 ? 7 : this.api.exchange_type;
    return {
      bid: bid,
      lab: {
        "poi_id": this.api.poi_id_str ? this.api.poi_id_str : this.api.poi_id,
        // couponType 为 7 时上报 couponType，其余情况使用 exchange_type
        "coupon_source": coupon_source,
        'red_threshold': this.api.origin_coupon_use_limit,
        'coupon_amount': this.api.poi_coupon_amount,
        'red_label': this.api.coupon_label
      }
    };
  },
  clickCancleLXReport: function clickCancleLXReport() {
    var bid = "";
    if (this.api.request_page_source == 1) {
      bid = "b_hjq226tu";
    } else if (this.api.request_page_source == 2) {
      bid = "b_bc9nwqad";
    }
    var coupon_source = this.api.couponType == 7 ? 7 : this.api.exchange_type;
    return {
      bid: bid,
      lab: {
        "poi_id": this.api.poi_id_str ? this.api.poi_id_str : this.api.poi_id,
        "coupon_source": coupon_source
      }
    };
  },
  doNothing: function doNothing() {
    // 为了拦截掉蒙版在内容区的事件响应
  },
  setApiValue: function setApiValue(api) {
    this.api = api;
  },
  setMachEnv: function setMachEnv(env) {
    this.env = env;
  }
};
exports["default"] = _default;
Object.defineProperty(_default, "computed", {
  get: function () {
    return _default.value.computed;
  }
});

/***/ })
/******/ ]);
if (this.customConfig && this.customConfig.name) {this[this.customConfig.name] = this.default.default} else {this.defaultObject = this.default.default};this.default=null;